package com.example.exercise.repository

import com.example.exercise.data.UserApi
import com.example.exercise.data.responses.User
import com.example.exercise.utils.Resource
import android.widget.Toast
import dagger.hilt.android.scopes.ActivityScoped
import javax.inject.Inject


class UserRepository @Inject constructor(
    private val api: UserApi
) {

    suspend fun getUserList(): Resource<List<User>> {
        val response = try {
            api.getUserList()
        } catch(e: Exception) {
            return Resource.Error("Error finding User Data.")
        }
        return Resource.Success(response)
    }
}