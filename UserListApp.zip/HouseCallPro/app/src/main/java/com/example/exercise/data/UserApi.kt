package com.example.exercise.data

import com.example.exercise.data.responses.User
import retrofit2.http.*

interface UserApi {

    @GET("users")
    suspend fun getUserList(
    ): List<User>

}