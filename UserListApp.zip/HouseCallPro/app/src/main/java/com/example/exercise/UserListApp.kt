package com.example.exercise

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class UserListApp: Application()