package com.example.exercise.utils

object Constants {

    const val BASE_URL = "http://jsonplaceholder.typicode.com/"

}